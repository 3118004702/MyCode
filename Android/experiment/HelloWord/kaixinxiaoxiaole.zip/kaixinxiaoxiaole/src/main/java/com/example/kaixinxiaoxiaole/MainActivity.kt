package com.example.kaixinxiaoxiaole

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main);

//        var view1 = findViewById<TextView>(R.id.textView);
//        var draw = getDrawable(R.drawable.xiao);
//        if (draw != null) {
//            draw.setBounds(150,150,250,250)
//        };
//        view1.setCompoundDrawables(draw,null,null,null);


    }
}