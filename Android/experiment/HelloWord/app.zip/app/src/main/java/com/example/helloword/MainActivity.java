package com.example.helloword;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText phoneEdit, nameEdit;
    private Button register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();

        register = (Button) findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                register();
            }
        });
    }
    private void init() {
        phoneEdit = (EditText) findViewById(R.id.phoneedit);
        nameEdit = (EditText) findViewById(R.id.nameedit);
    }
    public  void register() {
        //获取手机号码与昵称
        String phone = phoneEdit.getText().toString().trim();
        String name = nameEdit.getText().toString().trim();

        //手机号码和昵称均不可为空
        if (TextUtils.isEmpty(phone) || TextUtils.isEmpty(name)) {
            Toast.makeText(this, "选项不能为空", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent =new Intent(this, MainActivity2.class);
        intent.putExtra("phone",phone);
        intent.putExtra("name",name);

        startActivity(intent);
    }
}